import random
import math

class Tree:
    def __init__(self, value=None, decision=False):
        self.subtrees = {}
        self.decision = decision
        self.value = value

    def __str__(self):
        if self.decision:
            return "(" + str(self.value) + ")"
        else:
            return str(self.value)

    def decide(self, inputcase):
        if self.decision:
            return self.value
        else:
            return self.subtrees[inputcase[self.value]].decide(inputcase)

    def size(self):
        size = 1
        for key in self.subtrees.keys():
           size += self.subtrees[key].size()

        return size


    def printTree(self, indentlevel=0):
        if 1 in self.subtrees.keys():
            self.subtrees[1].printTree(indentlevel+1)
        print(' - '*indentlevel, end='') 
        print(self)
        if 2 in self.subtrees.keys():
            self.subtrees[2].printTree(indentlevel+1)


def pluralityValue(examples):
    pluralityMap = {}

    for example in examples:
        pluralityMap[example[~0]] = pluralityMap.get(example[~0], 0) + 1

    #print("pluralityValue:", pluralityMap, len(examples))

    if pluralityMap[1] == pluralityMap[2]:
        return random.choice([1,2])
    
    return max(pluralityMap, key=pluralityMap.get)



def booleanEntropy(q):
    try:
        return -(q*math.log(q,2) + (1-q)*math.log(1-q,2))
    except ValueError:
        return 0


def importance(attribute, examples, mode):
    if mode == 'random':
        return random.random()
    elif mode == 'entropy':
        total_pos_ex = 0
        total_neg_ex = 0
        remainder = 0
        for value in [1,2]:
            pos_ex = 0
            neg_ex = 0
            for example in examples:
                if example[attribute] == value and example[~0] == 1:
                    pos_ex += 1
                elif example[attribute] == value and example[~0] == 2:
                    neg_ex += 1

            if pos_ex or neg_ex:
                num_ex = pos_ex + neg_ex
                remainder += num_ex*booleanEntropy(pos_ex/num_ex)

            total_pos_ex += pos_ex 
            total_neg_ex += neg_ex 


        total_num_ex = total_pos_ex + total_neg_ex
        remainder /= total_num_ex

        entropy = booleanEntropy(total_pos_ex/total_num_ex)

        #print("Rem:", remainder)

        return entropy - remainder
    else:
        print("Mode", mode, "not implemented")
        exit(1)

def sameClassification(examples):
    # assumes examples is non empty
    c = examples[0][~0]
    for example in examples:
        if example[~0] != c:
            return False

    return True

def argmax(values):
    return max(list(enumerate(values)), key=lambda x: x[1])[0]

def decisionTreeLearning(examples, attributes, parent_examples, mode='entropy'):
    if not examples:
        return Tree(value=pluralityValue(parent_examples), decision=True)
    elif sameClassification(examples):
        return Tree(value=examples[0][~0], decision=True)
    elif not attributes:
        return Tree(value=pluralityValue(examples), decision=True)
    else:
        best_index = argmax([importance(a, examples, mode=mode) for a in attributes])
        tree = Tree(value=attributes[best_index])

        reduced_attributes = attributes[:best_index] + attributes[best_index+1:]
        for value in [1, 2]:
            exs = [e for e in examples if e[best_index] is value]

            tree.subtrees[value] = decisionTreeLearning(exs, attributes, examples, mode)

        return tree

#def exportToLatex(tree):
#    #based on simple-tree http://www.texample.net/tikz/examples/tree/
#    #needs to be fine tuned after exporting :(
#
#    print(r"\begin{tikzpicture}[\n\t"+\
#            r"every node/.style = {shape=rectangle, rounded corners,"+"\n\t\t"+\
#            r"draw, align=center, top color=white, bottom color=blue!20},"+"\n"+\
#            r"level 1/.style={sibling distance=10em},"+"\n"+\
#            r"level 2/.style={sibling distance=20em},"+"\n"+\
#            r"level 3/.style={sibling distance=40em},"+"\n"+\
#            r"level 4/.style={sibling distance=80em}"+"]\n", end='')
#
#    recurseTree(tree)
#
#    print(r";")
#
#    print(r"\end{tikzpicture}")
#
#def recurseTree(tree, level=0):
#    if level==0:
#        print(r"\node {{{0}}}".format(tree.value), end='')
#        for label, subtree in tree.subtrees.items():
#            recurseTree(subtree,level+1)
#        #print(r"}", end='')
#    elif tree.decision is False:
#        #tree has value (and should also have subtrees)
#        print(' '*level, end='')
#        print(r"child {{ node {{{0}}}".format(tree.value),end='')
#        for label, subtree in tree.subtrees.items():
#            recurseTree(subtree, level+1)
#        print(r"}", end='')
#    else:
#        # tree has decision
#        print(r"child {{ node {{{0}}} }}".format(str(tree)), end='')
#

def main():
    random.seed(0) # make random deterministic for testing


    mode = 'random'
    random_times = 10000 # times to run it in random mode
    training_data = "ex3-data/training.txt"
    validation_data = "ex3-data/test.txt"

    f = open(training_data,'r')
    examples = []
    for line in f:
        examples.append(list(map(int, line.split())))
    f.close()
    
    attributes = list(range(len(examples[0][:~0]))) # 0,1,2,3 ... one number for each attribute

    f = open(validation_data,'r')
    cases = []
    for line in f:
        cases.append(list(map(int, line.split())))
    f.close()

    total = len(cases)

    sizes = []
    accuracies = []
    for _ in range(random_times):
        tree = decisionTreeLearning(examples, attributes, examples,'random')
        correct = 0
        for case in cases:
            prediction = tree.decide(case)
            if prediction == case[~0]:
                correct += 1
        sizes.append(tree.size())
        accuracies.append(correct/total)


    print("-"*5 + "Tree statistics with random importance" + "-"*5)
    print("\tTimes run:", random_times)
    size_avg = sum(sizes)/random_times
    size_var = sum(map(lambda x: (x-size_avg)**2, sizes))/(random_times-1)
    print("\tAverage tree size (biggest/smallest): {0:.2f} ({1:.2f}/{2:.2f})".format(size_avg, max(sizes), min(sizes)))
    print("\tSize std dev: {0:.2f}".format(size_var**0.5))
    avg = sum(accuracies)/random_times
    print("\tAccuracy avg (best/worst): {0:.2f} ({1:.2f}/{2:.2f})".format(avg, max(accuracies), min(accuracies)))
    var = sum(map(lambda x: (x-avg)**2, accuracies))/(random_times-1)
    print("\tAccuracy std dev: {0:.2f}".format(var**0.5))

    tree = decisionTreeLearning(examples, attributes, examples,'entropy')
    correct = 0
    for case in cases:
        prediction = tree.decide(case)
        if prediction == case[~0]:
            correct += 1

    print("-"*5 + "Tree statistics with information gain importance" + "-"*5)
    print("\tTree size:", tree.size())
    print("\tAccuracy avg: {0:.2f}".format(avg))
   




    
main()
