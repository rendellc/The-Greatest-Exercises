#pragma once
#include <string>
using namespace std;


void mySwap(char& left, char& right);
string swapReverse(string& input);
string recursiveReverse(string input);