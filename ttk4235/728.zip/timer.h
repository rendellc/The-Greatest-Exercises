//
//  Timer.h
//  HeisprosjektTest
//
//  Created by Andrea Holten on 23.02.2017.
//  Copyright © 2017 Andrea Holten. All rights reserved.
//


#include <stdio.h>



void timer_start();
int timer_end();

