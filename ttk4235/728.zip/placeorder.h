

int po_add_order(int button_type, int floor);
void po_delete_order(int button);
void po_delete_all_orders();
int po_check_order(int button);