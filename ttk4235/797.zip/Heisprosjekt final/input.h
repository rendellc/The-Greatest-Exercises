void order_placed(void);
