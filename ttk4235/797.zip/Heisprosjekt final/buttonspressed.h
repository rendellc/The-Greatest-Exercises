void clear_orders(void);
void set_button_pressed(int index);
int get_button_pressed(int index);
void reset_button_pressed(int index);
int sum_of_buttons_pressed(void);
